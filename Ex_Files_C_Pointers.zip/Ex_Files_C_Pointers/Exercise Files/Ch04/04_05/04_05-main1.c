#include <stdio.h>

int main()
{
	printf("The main() function's address is %p\n",
			main
		  );

	return(0);
}
